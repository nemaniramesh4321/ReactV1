module.exports = function () {
    var data = {
		applicationNo: [
            { id:1, la:10010, ec: 10010}

        ],
        country: [
            { id:"C640CFE0-49AA-4A2D-A8C5-60501F81DB76", name: "India"},
			{ id:"7E50082B-89DC-4F43-8A1C-CD027B746FDA", name: "Australia"},
			{ id:"229D74D1-D709-40D7-8439-E0D3BB6676D3", name: "Dubai"},
			{ id:"0754C7A5-4696-48E7-87BC-EC0E91BDE8C7", name: "America"}

        ],
		eligibilitycheck: [
            { id:"520502B6-EE75-4C45-BF94-114C1F3CBBFD", ApplicationNumber:"EC10004", CustomerId:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", ProductId:"64373CC8-9A8F-452C-B2FC-7A75D90B35BC", RequestedAmount:10000.00, Tenor:12, CreatedBy:"1FF7134B-DB60-4188-B3D5-70A4F47CD9A2", CreatedOn:"2022-01-31 23:56:49.330"},
			{ id:"ACB34951-731F-4046-BF10-143B1C5ECB64", ApplicationNumber:"EC10003", CustomerId:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", ProductId:"64373CC8-9A8F-452C-B2FC-7A75D90B35BC", RequestedAmount:10000.00, Tenor:12, CreatedBy:"1FF7134B-DB60-4188-B3D5-70A4F47CD9A2", CreatedOn:"2022-01-31 23:56:34.387"},
			{ id:"6AF2B482-2A84-4F67-BE1F-49811E5FD5F7", ApplicationNumber:"EC10001", CustomerId:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", ProductId:"64373CC8-9A8F-452C-B2FC-7A75D90B35BC", RequestedAmount:10000.00, Tenor:12, CreatedBy:"1FF7134B-DB60-4188-B3D5-70A4F47CD9A2", CreatedOn:"2022-01-31 23:55:05.910"},
			{ id:"94958132-FED0-4D77-94EA-6EED246977A9", ApplicationNumber:"EC10002", CustomerId:"44F63887-8320-4443-94BE-10588AF083D1", ProductId:"16AD8A8C-190C-4509-805F-0FF99F3FA913", RequestedAmount:10000.00, Tenor:12, CreatedBy:"1FF7134B-DB60-4188-B3D5-70A4F47CD9A2", CreatedOn:"2022-01-31 23:55:59.993"},
			{ id:"46A9A236-903B-42BD-A885-8089479BD2BB", ApplicationNumber:"EC10002", CustomerId:"44F63887-8320-4443-94BE-10588AF083D1", ProductId:"16AD8A8C-190C-4509-805F-0FF99F3FA913", RequestedAmount:10000.00, Tenor:121, CreatedBy:"1FF7134B-DB60-4188-B3D5-70A4F47CD9A2", CreatedOn:"2022-01-31 23:55:48.643"},
			{ id:"DFC7A348-1F38-4E65-BA2E-D87E8EE04670", ApplicationNumber:"EC10003", CustomerId:"44F63887-8320-4443-94BE-10588AF083D1", ProductId:"16AD8A8C-190C-4509-805F-0FF99F3FA913", RequestedAmount:10000.00, Tenor:4, CreatedBy:"65024158-034B-4DF3-90A3-CAC84B9A481A", CreatedOn:"2022-02-01 21:58:21.203"},
        ],
		loanapplication: [
            { id:"8F540653-C79D-4D67-94E3-1490EF304B67", ApplicationNumber:"RLA10005", CustomerId:"44F63887-8320-4443-94BE-10588AF083D1", ProductId:"16AD8A8C-190C-4509-805F-0FF99F3FA913", RequestedAmount:2313123.00, Tenor:120, CreatedBy:"EFB6FCF1-9F4F-43A6-8394-0C6108E77AF7", CreatedOn:"2022-02-01 00:13:56.227", EligibleAmount:213333.00, EligiblilityCheck:"520502B6-EE75-4C45-BF94-114C1F3CBBFD", ApplicationStatus:"Pending", RealeasedAmount:0},
			{ id:"08BF67C4-36DD-465A-9E9C-17A442BD564A", ApplicationNumber:"RLA10001", CustomerId:"44F63887-8320-4443-94BE-10588AF083D1", ProductId:"16AD8A8C-190C-4509-805F-0FF99F3FA913", RequestedAmount:13432.00, 	Tenor:12, CreatedBy:"EFB6FCF1-9F4F-43A6-8394-0C6108E77AF7", CreatedOn:"2022-02-01 00:11:21.660", EligibleAmount:454534.00, EligiblilityCheck:"520502B6-EE75-4C45-BF94-114C1F3CBBFD", ApplicationStatus:"Pending", RealeasedAmount:0.00},
			{ id:"47E44B4D-6168-48C6-99A7-1D28ECC453BC", ApplicationNumber:"RLA10003", CustomerId:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", ProductId:"16AD8A8C-190C-4509-805F-0FF99F3FA913", RequestedAmount:0, 			Tenor:1, CreatedBy:"65024158-034B-4DF3-90A3-CAC84B9A481A", CreatedOn:"2022-02-02 10:51:12.930", EligibleAmount:1111.00, EligiblilityCheck:"520502B6-EE75-4C45-BF94-114C1F3CBBFD", ApplicationStatus:"Pending", RealeasedAmount:1111.00},
			{ id:"241640C7-9553-45CC-BBF2-3E065EC2EFC5", ApplicationNumber:"RLA10003", CustomerId:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", ProductId:"64373CC8-9A8F-452C-B2FC-7A75D90B35BC", RequestedAmount:435324.00, 	Tenor:120, CreatedBy:"EFB6FCF1-9F4F-43A6-8394-0C6108E77AF7", CreatedOn:"2022-02-01 00:12:59.483", EligibleAmount:2323213.00, EligiblilityCheck:"520502B6-EE75-4C45-BF94-114C1F3CBBFD", ApplicationStatus:"Pending", RealeasedAmount:2.00},
			{ id:"EC5B0945-DA72-46D8-8737-6B54D7A7A18D", ApplicationNumber:"RLA10002", CustomerId:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", ProductId:"64373CC8-9A8F-452C-B2FC-7A75D90B35BC", RequestedAmount:0, 			Tenor:12, CreatedBy:"EFB6FCF1-9F4F-43A6-8394-0C6108E77AF7", CreatedOn:"2022-02-01 00:12:15.653", EligibleAmount:454534.00, EligiblilityCheck:"6AF2B482-2A84-4F67-BE1F-49811E5FD5F7", ApplicationStatus:"Pending", RealeasedAmount:0.00},
			{ id:"C066ACBF-667F-4E22-AA21-92BAB20E96D4", ApplicationNumber:"RLA10002", CustomerId:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", ProductId:"64373CC8-9A8F-452C-B2FC-7A75D90B35BC", RequestedAmount:0, 			Tenor:1, CreatedBy:"65024158-034B-4DF3-90A3-CAC84B9A481A", CreatedOn:"2022-02-02 10:48:10.450", EligibleAmount:1111.00, EligiblilityCheck:"6AF2B482-2A84-4F67-BE1F-49811E5FD5F7", ApplicationStatus:"Pending", RealeasedAmount:1111.00},
			{ id:"F65C2DB3-51EE-418B-AB8D-FEF69084C195", ApplicationNumber:"RLA10003", CustomerId:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", ProductId:"16AD8A8C-190C-4509-805F-0FF99F3FA913", RequestedAmount:13432.00, 	Tenor:12, CreatedBy:"EFB6FCF1-9F4F-43A6-8394-0C6108E77AF7", CreatedOn:"2022-02-01 00:12:36.407", EligibleAmount:454534.00, EligiblilityCheck:"6AF2B482-2A84-4F67-BE1F-49811E5FD5F7", ApplicationStatus:"Pending", RealeasedAmount:0.00},
        ],
		contact: [
            { id:"44F63887-8320-4443-94BE-10588AF083D1", FirstName:"Halia", LastName:"Hiklak",	FullName:"Halia Hiklak", Age:32, MonthlyIncome:10000.00},
			{ id:"4902E4A6-BC98-498E-BF4E-1786051FB222", FirstName:"Roger", LastName:"Waters", FullName:"Roger Waters", Age:32, MonthlyIncome:10000.00},
			{ id:"A1006C32-93B1-40A9-93EE-1C6A19E925D4", FirstName:"Account", LastName:"Manager", FullName:"Account Manager", Age:32, MonthlyIncome:10000.00},
			{ id:"9ADFFCD3-F5C3-46AA-8D96-1E8AC70B7D0D", FirstName:"Adrien", LastName:"Smith", FullName:"Adrien Smith", Age:32, MonthlyIncome:10000.00},
			{ id:"22D1846C-A0EF-444F-AA62-3D0470AF43D1", FirstName:"Brian", LastName:"Blake", FullName:"Brian Blake", Age:32, MonthlyIncome:10000.00},
			{ id:"C4CF8FA1-ABD9-4EEE-B9F8-41D7C5BD8521", FirstName:"Susan", LastName:"Burk", FullName:"Susan Burk", Age:32, MonthlyIncome:10000.00},
			{ id:"A8387384-EF2D-4E5A-94F0-548EAEBF48B9", FirstName:"Adam", LastName:"Smith", FullName:"Adam Smith", Age:32, MonthlyIncome:10000.00},
			{ id:"AFEBE0C7-CDC5-4E21-B524-5BD1ED0C1244", FirstName:"sadasdsa", LastName:"sadsadsa", FullName:"sadasdsa sadsadsa", Age:32, MonthlyIncome:10000.00},
			{ id:"77DF3BB5-AC29-4FC5-A4C0-C29A951C4F5C", FirstName:"Archie", LastName:"James", FullName:"Archie Andrews", Age:32, MonthlyIncome:10000.00},
        ],
		product: [
            { id:"16AD8A8C-190C-4509-805F-0FF99F3FA913", ProductCode:"MG", ProductName:"Mortgage"},
			{ id:"64373CC8-9A8F-452C-B2FC-7A75D90B35BC", ProductCode:"PL", ProductName:"Personal Loan"},
			{ id:"55BF148D-5285-4E88-B4D2-80514721FF36", ProductCode:"AL", ProductName:"Auto Loan"},
        ],
		user: [
            { id:"EFB6FCF1-9F4F-43A6-8394-0C6108E77AF7", Name:"SalesUser", UserName:"Sales", Password:"Pass"},
			{ id:"1FF7134B-DB60-4188-B3D5-70A4F47CD9A2", Name:"Admin", UserName:"Admin", Password:"Pass"},
			{ id:"65024158-034B-4DF3-90A3-CAC84B9A481A", Name:"OrganizationAdmin", UserName:"OrgAdmin", Password:"Pass"},
        ],
        
    }
    return data
}
