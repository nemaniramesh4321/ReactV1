import React, { Component } from "react";
import { BrowserRouter as Router, Route, Switch, Redirect, withRouter, Prompt }
    from "react-router-dom";
import { ToggleLink } from "./ToggleLink";

//import EligibilityCheckMain from "../CRM/EC/eligibilityCheckMain";
//import LoanApplicationMain from "../CRM/LA/loanApplicationMain";
import { LoanApplicationMain } from "../CRM/LA/loanApplicationMain";
import { EligibilityCheckMain } from "../CRM/EC/eligibilityCheckMain";
//import RetailLoanApplicationMain from "../CRM/RLA/retailLoanApplicationMain";
//import { LoanApplicationMain } from "../CRM/RLA/retailLoanApplicationMain";
//import ContactsMain from "../CRM/Contacts/contactsMain";
//import { ContactsMain } from "../CRM/Contacts/contactsMain";
//import ProductsMain from "../CRM/Products/productsMain";
//import { ProductsMain } from "../CRM/Products/productsMain";

export default class VeriloanApp extends Component {
    constructor(props){
        super(props);
        this.state ={
            noticeComponentCHanges : false
        }
    }
    render(){
        return(
            <Router>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-2">
                            <ToggleLink to="/eligibilitycheck">Eligibility Check</ToggleLink>
                            <ToggleLink to="/loanapplication">Loan Application</ToggleLink>
                        </div>
                        <div className="col">
                        <Switch>
                            {/* <Route path="/eligibilitycheck" component={ EligibilityCheckMain } /> */}
                            <Route path="/eligibilitycheck" render={(props) => <EligibilityCheckMain changes={this.state.noticeComponentCHanges} {...this.props}/>} />
                            <Route path="/loanapplication" render={(props) => <LoanApplicationMain {...this.props}/>} />
                        </Switch>
                        </div>
                    </div>
                </div>
            </Router>
        );
    }
}