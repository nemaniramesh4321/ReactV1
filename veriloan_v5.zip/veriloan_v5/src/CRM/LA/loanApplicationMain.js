import React, { Component, useState, useEffect, useContext, useCallback} from "react";
import { LOANAPPLICATION } from "../../CRMDataProvider/Helpers/entitysandActions";
import ExistingLA from "./existingLA";
import RecordViewRla from "./recordViewLA";
import { connect } from "react-redux";
import { getData } from "../../graphql/GraphQLMiddleware";

const mapStateToProps = (storeData) => ({
    //editingView: storeData
    laRecords: storeData.modelData.loanApplication
})

const mapDispatchToProps = {
    getData: (type) => getData(type)
}
const connectFunction = connect(mapStateToProps, mapDispatchToProps);

export const LoanApplicationMain = connectFunction(function LoanApplicationMain_1(props) {
//export function LoanApplicationMain(props) {
    debugger;
    const [ecs, setECRecords] = useState([]);
    const [whats, setWhat] = useState("");
    const [isrecordView, seisrecordView] = useState(false);
    const [isViewOnly, setisViewOnly] = useState(false);
    const [VERecord, setVERecord] = useState({});
    
    useEffect(() =>{
        debugger;
        props.getData(LOANAPPLICATION);
    })
    //const viewCBLA = useCallback((pr) =>{
    const viewCBLA = (pr) =>{
        debugger;
        var ec = props.laRecords.find(p => p.id ==pr)
        setVERecord(ec);
        setisViewOnly(true);
        seisrecordView(true)
    }//,[]);
    //const editCBLA = useCallback((pr) =>{
    const editCBLA = (pr) =>{
        debugger;
        var ec = props.laRecords.find(p => p.id ==pr)
        setVERecord(ec);
        seisrecordView(true)
    }//,[]);
    const deleteCBLA = useCallback((pr) =>{
        debugger;
        
    },[]);
    const calcelEditing = useCallback((pr) =>{
        debugger;
        setisViewOnly(false);
        seisrecordView(false)
    },[]);
    
    function getWhattoRender(){
        debugger;
        if(props.laRecords.length > 0){
            if(!isrecordView){
                return <div>
                <div>{whats}</div>
                <ExistingLA tableData ={props.laRecords} 
                viewCall ={viewCBLA} editCall ={editCBLA} deleteCall ={deleteCBLA}/>
            </div>
            }
            else{
                return <RecordViewRla isViewOnly={isViewOnly} retailloanapplication={VERecord} cancelCallback ={calcelEditing}/>
            }
        }
        else{
            return <div>Data Loading Please wait</div>
        }
        // if(props.laRecords.length > 0){
        //     return <ExistingLA tableData ={props.laRecords}/>
        // }
        // else{
        //     return <div>Data Loading Please wait</div>
        // }
    }
    return getWhattoRender()
}
)



