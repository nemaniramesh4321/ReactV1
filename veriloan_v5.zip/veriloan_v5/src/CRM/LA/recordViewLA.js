import React, { Component } from "react";
export default class RecordViewRla extends Component {
    constructor(props){
        super(props);
        debugger;
        var record = props.retailloanapplication;
        this.state ={
            formData:{
                id: record.id || "",
                
                applicationNumber: record.ApplicationNumber || "", 
                customerName: record.Customer.FullName || "", 
                productName: record.Product.ProductName || "",
                requestedAmount: record.RequestedAmount || "", 
                tenor: record.Tenor || "", 
                eligibleAmount: record.EligibleAmount || "",
                realeasedAmount: record.RealeasedAmount || "", 
                eligiblilityCheck: record.EligiblilityCheck.ApplicationNumber || "", 
                applicationStatus: record.ApplicationStatus || "",
                createdOn: record.createdOn || "", 
                createdByName: record.CreatedBy.Name || "", 
                
                customer_Id: record.CustomerId || "",
                product_Id: record.ProductId || "",
                //createdBy_Id: record.createdBy_Id || "",
            },
            
        }
        debugger;
    }
    handleChange = (ev) => {
        ev.persist();
        this.setState(state => state.formData[ev.target.name] =  ev.target.value);
    }
    render(){
        return(
            <div className="m-2">
                <div class="row">
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label >applicationNumber</label>
                            <input className="form-control" disabled={true} name="applicationNumber" onChange={ this.handleChange } value={ this.state.formData.applicationNumber }/>
                        </div><br/>
                    </div>
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>customerName</label>
                            <input className="form-control" disabled={this.props.isViewOnly} name="customerName" onChange={ this.handleChange } value={ this.state.formData.customerName }/>
                        </div><br/>
                    </div>
                </div>
                <div className="form-group">
                    <label >productName</label>
                    <input className="form-control" disabled={true} name="productName" onChange={ this.handleChange } value={ this.state.formData.productName }/>
                </div><br/>
                <div class="row">
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>requestedAmount</label>
                            <input className="form-control" disabled={this.props.isViewOnly} name="requestedAmount" onChange={ this.handleChange } value={ this.state.formData.requestedAmount }/>
                        </div><br/>
                    </div>
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>tenor</label>
                            <input className="form-control" disabled={this.props.isViewOnly} name="tenor" onChange={ this.handleChange } value={ this.state.formData.tenor }/>
                        </div><br/>
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>eligibleAmount</label>
                            <input className="form-control" disabled={this.props.isViewOnly} name="eligibleAmount" onChange={ this.handleChange } value={ this.state.formData.eligibleAmount }/>
                        </div><br/>
                    </div>
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>realeasedAmount</label>
                            <input className="form-control" disabled={this.props.isViewOnly} name="realeasedAmount" onChange={ this.handleChange } value={ this.state.formData.realeasedAmount }/>
                        </div><br/>
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>eligiblilityCheck</label>
                            <input className="form-control" disabled={true} name="eligiblilityCheck" onChange={ this.handleChange } value={ this.state.formData.eligiblilityCheck }/>
                        </div><br/>
                    </div>
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>applicationStatus</label>
                            <input className="form-control" disabled={true} name="applicationStatus" onChange={ this.handleChange } value={ this.state.formData.applicationStatus }/>
                        </div><br/>
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>createdOn</label>
                            <input className="form-control" disabled={true} name="createdOn" onChange={ this.handleChange } value={ this.state.formData.createdOn }/>
                        </div><br/>
                    </div>
                    <div class="col s12 m6">
                        <div className="form-group">
                            <label>createdByName</label>
                            <input className="form-control" disabled={true} name="createdByName" onChange={ this.handleChange } value={ this.state.formData.createdByName }/>
                        </div><br/>
                    </div>
                </div>
                <div className="text-center">
                    <button className="btn btn-primary m-1" onClick={() =>this.props.saveCallback(this.state.formData)}>Save</button>
                    <button className="btn btn-secondary m-1" onClick={this.props.cancelCallback}>Cancel</button>
                </div>
            </div>
        );
    }
}