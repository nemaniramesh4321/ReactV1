import React, { Component, useState, useEffect, useContext, memo } from "react";
import TableBodyV2 from "../../CommonContents/TableElements/tableBodyV2";


const ExistingLA = (props) => {
    debugger;
//export function ExistingECs(props) {
    function getTableBody(){
        debugger;
        const rows =[];
        props.tableData.forEach((p, i) =>{
            rows.push(
                
            <TableBodyV2 attrs={p} key={p.id} buttonConfig={[true, true, true]} editCallback={ props.editCall }
            deleteCallback={ props.deleteCall } viewCB={props.viewCall}/>
            )
        })
        return rows;
    }
    function createRLATable(){
        var rows = getTableBody();
        return(
            <table className="table table-sm table-striped table-bordered">
                <thead>
                <tr><th colSpan="9" className="bg-info text-white text-center h4 p-2">
                        Existing Retail Loan Applications
                    </th></tr>
                    <tr>
                    <th>RLA Name</th>
                    <th>Customer</th>
                    <th>Loan Type</th>
                    <th>R.Amount</th>
                    <th>Tenor</th>
                    <th>Elg.Amount</th>
                    <th>EC</th>
                    <th>Status</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>{rows}</tbody>
        </table>
        )
    }
    return createRLATable();
}

export default memo(ExistingLA);