import React, { Component, useState, useEffect, useContext, memo } from "react";
import TableBodyV2 from "../../CommonContents/TableElements/tableBodyV2";

const ExistingECs = (props) => {
    debugger;
//export function ExistingECs(props) {
    
    function getTableBody(){
        const rows =[];
        props.tableData.forEach((p, i) =>{
        rows.push(
            <TableBodyV2 attrs={p} key={i} buttonConfig={[true, true, true]} editCallback={ props.editCall }
            deleteCallback={ props.deleteCall } viewCB={props.viewCall}/>
            )
        })
        return rows;
    }
    function createECTable(){
        debugger;
        var rows =getTableBody();
        return(
            <table className="table table-sm table-striped table-bordered">
                <thead>
                <tr><th colSpan="8" className="bg-info text-white text-center h4 p-2">
                        Existing Eligibility Check's
                    </th></tr>
                    <tr>
                    <th>EC Name</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Requested Amount</th>
                    <th>Tenor</th>
                    <th>Created By</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>{rows}</tbody>
        </table>
        )
    }
    return(
        createECTable()
    )
}
export default ExistingECs;