import React, { Component, useState, useEffect, useContext, useCallback, useMemo} from "react";
import { ELIGIBILITYCHECK } from "../../CRMDataProvider/Helpers/entitysandActions";
//import ExistingECs from "./existingECs";
//import { ExistingECs } from "./existingECs";
import RecordViewEc from "./recordViewEc";
import ExistingECs from "./existingECs";
import { connect } from "react-redux";
import { getData } from "../../graphql/GraphQLMiddleware";

const mapStateToProps = (storeData) => ({
    //editingView: storeData
    ecRecords: storeData.modelData.eligibilityCheck
})

const mapDispatchToProps = {
    getData: (type) => getData(type)
}
const connectFunction = connect(mapStateToProps, mapDispatchToProps);

export const EligibilityCheckMain = connectFunction(function EligibilityCheckMain_1(props) {
//export function EligibilityCheckMain(props) {
    debugger;
    const [ecs, setECRecords] = useState([]);
    const [whats, setWhat] = useState("");
    const [isrecordView, seisrecordView] = useState(false);
    const [isViewOnly, setisViewOnly] = useState(false);
    const [VERecord, setVERecord] = useState({});
    
    useEffect(() =>{
        debugger;
        props.getData(ELIGIBILITYCHECK);
    },[])
    //const viewCBEC = useCallback((pr) =>{
    const viewCBEC = (pr) =>{
        debugger;
        var ec = props.ecRecords;
        var ec = props.ecRecords.find(p => p.id ==pr)
        setVERecord(ec);
        setisViewOnly(true);
        seisrecordView(true)
        setWhat("viewCBEC ID is:" + pr);
    }//,[]);
    const editCBEC = (pr) =>{
        debugger;
        var ec = props.ecRecords.find(p => p.id ==pr)
        setVERecord(ec);
        seisrecordView(true)
        setWhat("editCBEC ID is:" + pr);
    }//,[]);
    //const deleteCBEC = useCallback((pr) =>{
    const deleteCBEC = (pr) =>{
        debugger;
        setWhat("deleteCBEC ID is:" + pr);
    }//,[]);
    const calcelEditing = useCallback((pr) =>{
        debugger;
        setisViewOnly(false);
        seisrecordView(false)
    },[]);
    const existingTable = useMemo(() => ExistingECs({tableData:props.ecRecords,viewCall:viewCBEC,editCall:editCBEC,deleteCall:deleteCBEC  }), [props.ecRecords]);
    function getWhattoRender(){
        debugger;
        if(props.ecRecords.length > 0){
            if(!isrecordView){
                return <div>
                <div>{whats}</div>
                {/* <ExistingECs tableData ={props.ecRecords} 
                viewCall ={viewCBEC} editCall ={editCBEC} deleteCall ={deleteCBEC}/> */}
                {existingTable}
            </div>
            }
            else{
                return <RecordViewEc isViewOnly={isViewOnly} eligibilitycheck={VERecord} cancelCallback ={calcelEditing}/>
            }
        }
        else{
            return <div>Data Loading Please wait</div>
        }
    }
    return getWhattoRender()
}
)



