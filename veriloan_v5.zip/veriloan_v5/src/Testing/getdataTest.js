import React, { Component } from "react";
//import { VeriDataGetter } from "../CRMDataProvider/veriDataGetter";

export default class GetdataTest extends Component {
    constructor(props){
        super(props);
        this.state = {
            ecs: []
            }
            //this.datasource = new VeriDataGetter("EC");
    }
    getLKPData=()=>{
        debugger;
        //this.datasource.getLookupData(data => this.setState({ecs: data}));
        this.datasource.getLookupData(this.tryCallback);
        var x = this.ecs;
        debugger;
    }
    tryCallback =(data)=>{
        debugger;
        this.setState({ecs : data})
        var x = this.state.ecs;
        debugger;
    }

    render(){
        return(
            <div>
                <button onClick={() =>this.getLKPData()}>Get LookupData</button>
            </div>
        )
    }

}