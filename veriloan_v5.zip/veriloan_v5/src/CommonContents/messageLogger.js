import React, { Component } from "react";


export default class MessageLogger extends Component {
    
    render(){
        let elements=[];
        this.props.logging.forEach((element, i) => {
            elements.push(<div key={i}>{element}</div>)
        });
        return(
            <React.Fragment>
                <div className="text-center">
                        <button className="btn btn-primary m-1" onClick={ this.props.clearMessages }>Clear All</button>
                    </div>
                <div className="bg-info">
                        <pre className="text-white">
                            {elements}
                        </pre>
                    </div>
            </React.Fragment>
        )
    }
}