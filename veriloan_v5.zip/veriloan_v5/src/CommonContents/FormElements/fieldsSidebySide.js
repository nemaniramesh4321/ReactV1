import React, { Component } from "react";

export default class FieldsSidebySide extends Component {
    
}