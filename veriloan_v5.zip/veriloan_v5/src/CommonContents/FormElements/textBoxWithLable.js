import React, { Component } from "react";

export default class TextBoxWithLable extends Component {
    render(){
        return(
            <div className="form-group">
                <label >{this.props.lableName}</label>
                <input className="form-control" disabled={this.props.tbxDisabled} name={this.props.tName} 
                onChange={ this.props.CBhandleChange } value={ this.props.tValue }/>
            </div>
        );
    }
}