import React, { Component } from "react";

export default class TableBody extends Component {
    getButtons=()=>{
        let p= this.props.attrs.id;
        let buttonsConfig =[];
          if(this.props.buttonConfig[0]){
            buttonsConfig.push(<button className="btn btn-sm btn-info m-1" onClick={() =>this.props.viewCB(p)}>View</button>)
          }
          if(this.props.buttonConfig[1]){
            buttonsConfig.push(<button className="btn btn-sm btn-warning m-1" onClick={() =>this.props.editCallback(p)}>Edit</button>)
          }
          if(this.props.buttonConfig[2]){
            buttonsConfig.push(<button className="btn btn-sm btn-danger m-1" onClick={ () => this.props.deleteCallback(p) }>Delete</button>)
          }
          return buttonsConfig;
    }
    getProperties=()=>{
        let tds =[];
        Object.entries(this.props.attrs).map(item => {
          var x1 = item[0];
          var x2 = item[1];
          //debugger;
            if(item[0] != "id" && item[0] != "isEligible" && item[0] != "Product" && item[0] != "Customer" && item[0] != "CreatedBy"){
                tds.push(<td>{item[1]}</td>);
            }
          })
          return tds;
    }
    render(){
        return(
            <tr>
                {/* {tds} */}
                {this.getProperties()}
                <td>
                    {this.getButtons()}
                </td>
            </tr>
        );
    }
}