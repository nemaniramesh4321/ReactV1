import React, { Component } from "react";

export default class TableBodyV2 extends Component {
    getButtons=()=>{
        let p= this.props.attrs.id;
        let buttonsConfig =[];
          if(this.props.buttonConfig[0]){
            buttonsConfig.push(<button className="btn btn-sm btn-info m-1" onClick={() =>this.props.viewCB(p)}>View</button>)
          }
          if(this.props.buttonConfig[1]){
            buttonsConfig.push(<button className="btn btn-sm btn-warning m-1" onClick={() =>this.props.editCallback(p)}>Edit</button>)
          }
          if(this.props.buttonConfig[2]){
            buttonsConfig.push(<button className="btn btn-sm btn-danger m-1" onClick={ () => this.props.deleteCallback(p) }>Delete</button>)
          }
          return buttonsConfig;
    }
    getProperties=()=>{
        let tds =[];
        Object.entries(this.props.attrs).map(item => {
            //debugger;
          var value  = this.valueProvider(item)
          //debugger;
          if(value != null){
            tds.push(<td>{value}</td>);
          }
            // if(item[0] != "id" && item[0] != "isEligible" && item[0] != "Product" && item[0] != "Customer" && item[0] != "CreatedBy"){
            //     tds.push(<td>{item[1]}</td>);
            // }
          })
          return tds;
    }
    valueProvider=(item)=>{
        var x1 = item[0];
        var x2 = item[1];
        if(typeof x2 ==='string'){
            const regexExp = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/gi;
            var isguid = regexExp.test(x2);
            if(isguid){
                return null;
            }
            else{
                return x2;
            }
        }
        else if(typeof x2 ==='object'){
            return Object.values(x2)[0];
        }
        else if(typeof x2 ==='number'){
            return x2;
        }
        else{
            return null;
        }
    }
    render(){
        return(
            <tr>
                {/* {tds} */}
                {this.getProperties()}
                <td>
                    {this.getButtons()}
                </td>
            </tr>
        );
    }
}