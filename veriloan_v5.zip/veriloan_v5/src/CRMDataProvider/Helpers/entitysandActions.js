export const ELIGIBILITYCHECK = "eligibilityCheck";
export const LOANAPPLICATION = "loanApplication";
export const CONTACTS = "contacts";
export const PRODUCTS = "products";


//Actions
export const CREATE = "Create";
export const READ = "Read";
export const UPDATE = "Update";
export const DELETE = "Delete";


export const STATE_START_EDITING = "state_start_editing";
export const STATE_END_EDITING = "state_end_editing";
export const STATE_START_CREATING = "state_start_creating";
export const STATE_START_VIEW = "state_start_view";