import { ELIGIBILITYCHECK, LOANAPPLICATION, CONTACTS, PRODUCTS } from "../Helpers/entitysandActions";
import { STATE_START_EDITING, STATE_END_EDITING, STATE_START_CREATING, STATE_START_VIEW} from "../Helpers/entitysandActions";



//Save Events
export const startEditingEC = (ecr) =>{
    return createStartEditingEvent(ELIGIBILITYCHECK, ecr);
}
export const startEditingRLA = (rlar) =>{
    return createStartEditingEvent(LOANAPPLICATION, rlar);
}
export const startEditingContact = (contactr) =>{
    return createStartEditingEvent(CONTACTS, contactr);
}
// export const endEditing = () => ({
    
//     type: STATE_END_EDITING
//     })
export const endEditing = (d) => {
    
    debugger;
    return{
        type: STATE_END_EDITING
    }
    }

export const startCreatingEC = () =>{
    return createStartCreatingEvent(ELIGIBILITYCHECK);
}
export const startCreatingRLA = () =>{
    return createStartCreatingEvent(LOANAPPLICATION);
}
export const startCreatingContact = () =>{
    return createStartCreatingEvent(CONTACTS);
}

export const startViewEC = (ecr) =>{
    return createStartViewEvent(ELIGIBILITYCHECK, ecr);
}
export const startViewRLA = (rlar) =>{
    return createStartViewEvent(LOANAPPLICATION, rlar);
}
export const startViewContact = (contactr) =>{
    return createStartViewEvent(CONTACTS, contactr);
}
export const startViewProduct = (productr) =>{
    return createStartViewEvent(PRODUCTS, productr);
}


//Generic Methods
const createStartEditingEvent =(entity, record) =>{
    return{
        type: STATE_START_EDITING,
        entity: entity,
        record: record
    }
}
const createStartViewEvent =(entity, record) =>{
    return{
        type: STATE_START_VIEW,
        entity: entity,
        record: record
    }
}
const createStartCreatingEvent =(entity) =>{
    return{
        type: STATE_START_CREATING,
        entity: entity
    }
}
