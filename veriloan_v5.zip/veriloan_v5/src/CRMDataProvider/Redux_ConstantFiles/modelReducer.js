import { ELIGIBILITYCHECK, LOANAPPLICATION, CONTACTS, PRODUCTS } from "../Helpers/entitysandActions";
import { CREATE, READ, UPDATE, DELETE } from "../Helpers/entitysandActions";
import { initialData } from "./InitialData";

export default function(storeData, action) {
    debugger;
    var x = initialData;
    switch(action.type){
        case CREATE:
            debugger;
            console.log(action.record);
            return{
                ...storeData,
                [action.entity]: storeData[action.entity].concat([action.record])
            }
        case UPDATE:
            debugger;
            return{
                ...storeData,
                [action.entity]: storeData[action.entity].map( p=> p.id === action.record.id ? action.record: p)
            }
        case DELETE:
            return{
                ...storeData,
                [action.entity]: storeData[action.entity].filter(p => p.id !== action.record)
            }
        default:
            //return storeData || initialData;
            x = initialData.modelData;
            debugger;
            return storeData || initialData.modelData;
    }
}










// export default function(storeData, action) {
//     debugger;
//     switch(action.type){
//         case UPDATE:
//             debugger;
//             return{
//                 ...storeData,
//                 // [action.dataType]: storeData[action.dataType].map( p=> p.id === action.payload.id ? action.payload: p)
//                 [action.dataType]: storeData[action.dataType].map(p => p.id === action.payload.id ? action.payload : p)

//             }
//             default:
//             //return storeData || initialData;
//             return storeData || initialData;
//     }
// }