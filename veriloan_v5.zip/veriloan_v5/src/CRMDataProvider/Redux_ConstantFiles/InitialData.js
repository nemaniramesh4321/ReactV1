import { ELIGIBILITYCHECK, LOANAPPLICATION, CONTACTS, PRODUCTS } from "../Helpers/entitysandActions"


export var initialData = {
    modelData:{
        [ELIGIBILITYCHECK]: [],
        [LOANAPPLICATION]: [],
        [CONTACTS]: [],
        [PRODUCTS]: [],
    },
    stateData: {
        editingView: false,
        isViewOnly: false,
        selectedId:"",
        selectedEntity: CONTACTS
    }
    
}