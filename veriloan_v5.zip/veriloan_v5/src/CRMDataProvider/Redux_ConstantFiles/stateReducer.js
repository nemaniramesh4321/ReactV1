import { ELIGIBILITYCHECK, LOANAPPLICATION, CONTACTS, PRODUCTS } from "../Helpers/entitysandActions";
import { STATE_START_EDITING, STATE_END_EDITING, STATE_START_CREATING, STATE_START_VIEW } from "../Helpers/entitysandActions";
//import { initialData } from "./delInitialData";
import { initialData } from "./InitialData";

export default function(storeData, action) {
    debugger;
    switch(action.type){
        case STATE_START_EDITING:
        case STATE_START_CREATING:
            return {
                ...storeData,
                editingView: true,
                selectedId: action.type === STATE_START_EDITING ? action.record:-1,//action.payload.id : -1,
                selectedEntity: action.entity
                }
        case STATE_END_EDITING:
            return {
                ...storeData,
                editingView: false,
                isViewOnly:false
            }
            case STATE_START_VIEW:
                return {
                    ...storeData,
                    editingView: true,
                    selectedId: action.type === STATE_START_VIEW ? action.record:-1,//action.payload.id : -1,
                    selectedEntity: action.entity,
                    isViewOnly:true
                    }
        
        default:
            return storeData || initialData.stateData;
    }
}










// export default function(storeData, action) {
//     debugger;
//     switch(action.type){
//         case UPDATE:
//             debugger;
//             return{
//                 ...storeData,
//                 // [action.dataType]: storeData[action.dataType].map( p=> p.id === action.payload.id ? action.payload: p)
//                 [action.dataType]: storeData[action.dataType].map(p => p.id === action.payload.id ? action.payload : p)

//             }
//             default:
//             //return storeData || initialData;
//             return storeData || initialData;
//     }
// }