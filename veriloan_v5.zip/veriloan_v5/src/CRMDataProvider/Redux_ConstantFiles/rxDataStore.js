import { createStore, combineReducers, applyMiddleware, compose } from "redux";
import modelReducer from "./modelReducer";
import stateReducer from "./stateReducer";
//import { customReducerEnhancer } from "../ReduxAPIWorker/customReducerEnhancer";
//import { multiActions } from "../ReduxAPIWorker/multiActionMiddleware";
//import { asyncEnhancer } from "../ReduxAPIWorker/asyncEnhancer";
//import { createRestMiddleware } from "../RestMiddleware";
import { createGraphQLMiddleware } from "../../graphql/GraphQLMiddleware";
import { multiActions } from "./multiActionMiddleware";


//export default createStore(modelReducer);
// export default createStore(combineReducers(
//     {
//     modelData: modelReducer,
//     stateData: stateReducer
//     }));


// const enhancedReducer = customReducerEnhancer(
//     combineReducers(
//     {
//     modelData: modelReducer,
//     stateData: stateReducer
//     })
//     );
const enhancedReducer =
    combineReducers(
    {
    modelData: modelReducer,
    stateData: stateReducer
    });

    // const restMiddleware = createRestMiddleware(
    //     "http://localhost:3500/api/products",
    //     "http://localhost:3500/api/suppliers");

//export default createStore(enhancedReducer);
//export default createStore(enhancedReducer, applyMiddleware(multiActions));
//export default createStore(enhancedReducer, compose(applyMiddleware(multiActions), asyncEnhancer(2000)));
// export default createStore(enhancedReducer, compose(applyMiddleware(multiActions),
//                 applyMiddleware(restMiddleware), 
//                 asyncEnhancer(2000)));
// export default createStore(enhancedReducer, compose(applyMiddleware(multiActions),
//                 applyMiddleware(createGraphQLMiddleware()), 
//                 asyncEnhancer(2000)));
export default createStore(enhancedReducer, compose(applyMiddleware(multiActions),
                applyMiddleware(createGraphQLMiddleware()), 
                ));



export {SaveEC, SaveRLA, SaveContact, UpdateEC, UpdateRLA, UpdateContact, DeleteEC, DeleteRLA} from "./modelActionCreators";
//export {UpdateEC, SaveEC} from "./modelActionCreators";