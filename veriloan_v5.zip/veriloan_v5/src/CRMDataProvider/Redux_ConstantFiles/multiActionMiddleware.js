//export const multiActions = ({dispatch, getState}) => next => action => {
    export function multiActions({dispatch, getState}) {
        debugger;
        return function receiveNext(next) {
            debugger;
            return function processAction(action) {
                debugger;
                if (Array.isArray(action)) {
                    action.forEach(a => next(a));
                } else {
                    next(action);
                }
            }
        }
    }