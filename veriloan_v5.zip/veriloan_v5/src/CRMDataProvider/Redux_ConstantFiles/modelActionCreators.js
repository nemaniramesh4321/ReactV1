import { ELIGIBILITYCHECK, LOANAPPLICATION, CONTACTS, PRODUCTS } from "../Helpers/entitysandActions";
import { CREATE, READ, UPDATE, DELETE } from "../Helpers/entitysandActions";



//Save Events
export const SaveEC = (ecr) =>{
    return createSaveEvent(ELIGIBILITYCHECK, ecr);
}
export const SaveRLA = (rlar) =>{
    return createSaveEvent(LOANAPPLICATION, rlar);
}
export const SaveContact = (contactr) =>{
    return createSaveEvent(CONTACTS, contactr);
}

//Update Events
export const UpdateEC = (ecr) =>{
    debugger;
    return createUpdateEvent(ELIGIBILITYCHECK, ecr);
}
export default function UpdateECXX(ecr){
    debugger;
    return createUpdateEvent(ELIGIBILITYCHECK, ecr);
}
export const UpdateRLA = (rlar) =>{
    return createUpdateEvent(LOANAPPLICATION, rlar);
}
export const UpdateContact = (contactr) =>{
    return createUpdateEvent(CONTACTS, contactr);
}

//Delete Events
export const DeleteEC = (ecr) =>{
    debugger;
    return createDeleteEvent(ELIGIBILITYCHECK, ecr);
}
export const DeleteRLA = (rlar) =>{
    return createDeleteEvent(LOANAPPLICATION, rlar);
}




//Generic Methods
const createSaveEvent =(entity, record) =>{
    // return{
    //     type: CREATE,
    //     dataType: entity,
    //     payload: record
    // }
    return{
        type: CREATE,
        entity: entity,
        record: record
    }
}
const createUpdateEvent =(entity, record) =>{
    return{
        type: UPDATE,
        entity: entity,
        record: record
    }
}
const createDeleteEvent =(entity, record) =>{
    debugger;
    // return{
    //     type: DELETE,
    //     dataType: entity,
    //     payload: record.id
    // }
    return{
        type: DELETE,
        entity: entity,
        record: record
    }
}