import { SaveEC, SaveRLA, UpdateEC, UpdateRLA, UpdateContact } from "../ReduxWorkers/modelActionCreators";
import { ELIGIBILITYCHECK, LOANAPPLICATION, CONTACTS, PRODUCTS } from "../Helpers/entitysandActions";
import { endEditing } from "../ReduxWorkers/stateActionCreators";

export const saveAndEndEditing = (data, dataType) =>
[dataType === ELIGIBILITYCHECK ? SaveEC(data) : SaveRLA(data), endEditing()];

export const updateAndEndEditing = (data, dataType) =>
[dataType === ELIGIBILITYCHECK ? UpdateEC(data) : dataType === LOANAPPLICATION ? UpdateRLA(data): UpdateContact(data), endEditing()];