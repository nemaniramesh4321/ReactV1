import React, { Component } from "react";
import VeriloanApp from "./Apps/veriloanApp";
import { Provider } from "react-redux";
import rxDataStore from "./CRMDataProvider/Redux_ConstantFiles/rxDataStore";
import MessageLogger from "./CommonContents/messageLogger";

export default class App extends Component {
  constructor(props){
    super(props);
    this.state ={
      messages:[]
    }
  }
  addMessagetoLogging=(msg)=>{
    var m= this.state.messages;
    m.push(msg)
    this.setState({messages: m});
  }
  messagesClear=()=>{
    this.setState({messages : []})
  }

  getWhattoShow=()=>{
    //debugger;
      //var ctee = rxDataStore;
      //debugger;
      return (
        <div className="container-fluid">
          <div className="row">
            <div className="col-3">
              <MessageLogger logging={this.state.messages} clearMessages ={this.messagesClear}/>
            </div>
            <div className="col">
              <Provider store={rxDataStore}>
                <VeriloanApp addlogging={this.addMessagetoLogging}/>
              </Provider>
                {/* <VeriloanApp addlogging={this.addMessagetoLogging}/> */}
            </div>
          </div>
        </div>
      )
  }
  render(){
    return(
      <div>
        {this.getWhattoShow()}
      </div>
    )
  }
}


// getWhattoShow=()=>{
//   debugger;
//     var ctee = rxDataStore;
//     debugger;
//     return (
//       <div className="container-fluid">
//         <div className="row">
//           <div className="col-3">
//             <MessageLogger logging={this.state.messages}/>
//           </div>
//           <div className="col">
//           <Provider store={rxDataStore}>
//               <VeriloanApp addlogging={this.addMessagetoLogging}/>
//             </Provider>    
//           </div>
//         </div>
//       </div>
//     )
// }