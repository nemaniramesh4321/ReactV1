import { ELIGIBILITYCHECK, LOANAPPLICATION, CONTACTS, PRODUCTS} from "../CRMDataProvider/Helpers/entitysandActions";
import { UPDATE, CREATE, READ, DELETE} from "../CRMDataProvider/Helpers/entitysandActions";
import { GraphQLDataSource } from "./GraphQLDataSource";

export const GET_DATA = "qraphql_get_data";

export const getData = (entity) => {
    return {
        type: GET_DATA,
        entity: entity
    }
}

export const createGraphQLMiddleware = () => {
    
    const dataSources = {
        [ELIGIBILITYCHECK]: new GraphQLDataSource(ELIGIBILITYCHECK, () => {}),
        [LOANAPPLICATION]: new GraphQLDataSource(LOANAPPLICATION, () => {}),
    }
    
    return ({dispatch, getState}) => next => action => {
        switch (action.type) {
            case GET_DATA:
                debugger;
                if (getState().modelData[action.entity].length === 0) {
                    dataSources[action.entity].GetData((data) => 
                    
                        data.forEach(item => next({ type: CREATE, 
                            entity: action.entity, record: item})));
                }
                break;
            case CREATE:
                debugger;
                action.payload.id = null;
                dataSources[action.entity].Store(action.payload, data => 
                    next({ ...action, payload: data }))
                break;
            case UPDATE:          
                // dataSources[action.dataType].Update(action.payload, data => 
                //      next({ ...action, payload: data }))            
                break;
            case DELETE:
                // dataSources[action.dataType].Delete({id: action.payload }, 
                //     () => next(action));
                break;
            default:
                next(action);
        }
    }
}
