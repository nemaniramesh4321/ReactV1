export const eligibilitychecks = {
    store: {},
    delete:{},
}