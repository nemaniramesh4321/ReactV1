//var data = require("../../restData")();
var data = require("../../graphqlData")();

module.exports = {

countrys: () => data.country,
eligibilitychecks: () => data.eligibilitycheck.map(s => ({...s, 
    Customer: () => data.contact.find(p => p.id ==s.CustomerId),
    Product: () => data.product.find(p => p.id ==s.ProductId),
    CreatedBy: () => data.user.find(p => p.id ==s.CreatedBy)
})),

loanapplications: () => data.loanapplication.map(s => ({...s, 
    EligiblilityCheck: () => data.eligibilitycheck.find(p => p.id ==s.EligiblilityCheckId),
    Customer: () => data.contact.find(p => p.id ==s.CustomerId),
    Product: () => data.product.find(p => p.id ==s.ProductId),
    CreatedBy: () => data.user.find(p => p.id ==s.CreatedBy)
})),
    

contacts: () => data.contact,
products: () => data.product,
users: () => data.user,


applicationNos:() => data.applicationNo,//.find(p=> p.id === 1),
country: (args) => data.country.find(p=> p.id === args.id),

eligibilitycheck: (args) =>{
    const result = data.eligibilitycheck.find(s => s.id === args.id);
    if(result){
        return{
            ...result,
            Customer: () => data.contact.find(p => p.id ==result.CustomerId),
            Product: () => data.product.find(p => p.id ==result.ProductId),
            CreatedBy: () => data.user.find(p => p.id ==result.CreatedBy)
        }
    }
},



loanapplication: (args) =>{
    const result = data.loanapplication.find(s => s.id === args.id);
    if(result){
        return{
            ...result,
            EligiblilityCheck: () => data.eligibilitycheck.find(p => p.id ==result.EligiblilityCheck),
            Customer: () => data.contact.find(p => p.id ==result.CustomerId),
            Product: () => data.product.find(p => p.id ==result.ProductId)
        }
    }

},

contact: (args) => data.contact.find(p=> p.id === args.id),
product: (args) => data.product.find(p=> p.id === args.id),
user: (args) => data.user.find(p=> p.id === args.id),


storeEligibilityCheck({eligibilitycheck}){
if(eligibilitycheck.id != null){
    
}
},
updateApplicationNo(aggs){
    // if(aggs.type =="EC"){
    //     aggs.ec++;
    // }
    // if(aggs.type =="LA"){
    //     aggs.la++;
    // }
    // const nos = { id:1, la:aggs.la, ec:aggs.ec};
    // data.applicationNos = applicationNos.map(p =>p.id ===nos.id? nos: nos);
} 


}