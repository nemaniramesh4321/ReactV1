export const eligibilityCheck = {
    getAll: {
        name: "eligibilitychecks",
        graphql: `query {
            eligibilitychecks{
              id,
              ApplicationNumber,

              CustomerId,
              Customer{FullName},

              ProductId,
              Product{ProductName},

              RequestedAmount,
              Tenor,
              CreatedBy{Name},
            }
            }`
    },
}
export const loanApplication = {
    getAll: {
        name: "loanapplications",
        graphql: `query {
            loanapplications {
                    id,
                ApplicationNumber,
                CustomerId,
                Customer{FullName},
                ProductId,
                Product{ProductName},
                RequestedAmount,
                Tenor,
                CreatedBy{Name},
                EligibleAmount,
                  EligiblilityCheck{ApplicationNumber}
                ApplicationStatus,
                RealeasedAmount
            }
            }`
    },
}

export const suppliers = {
    getAll: {
        name: "suppliers",
        graphql:`query {
              suppliers { id, name, city, products { id, name }}
            }`
    },
    getOne: {
        name: "supplier",
        graphql: `query($id: ID!) {
                supplier(id: $id) {
                    id, name, city, products { id, name }
                }
            }`
    }
}
